import React, { useState } from 'react';
import './App.css';
import TextField from '@material-ui/core/TextField';
import InputAdornment from '@material-ui/core/InputAdornment';
import SendIcon from '@material-ui/icons/Send';
import Button from '@material-ui/core/Button';
import { makeStyles } from '@material-ui/core/styles';
import NotificationsIcon from '@material-ui/icons/Notifications';
import EmailIcon from '@material-ui/icons/Email';
import AccountCircleIcon from '@material-ui/icons/AccountCircle';

const useStyles = makeStyles({
  container: {
    display: 'flex',
    width: '30%',
    flexDirection: 'column',
    justifyContent: 'flex-start',
    alignItems: 'stretch',
    margin: '0 auto',
    marginTop: '50px',
    background: 'darkgray', // Change the background color of the container to dark gray
    padding: '16px', // Add padding to the container
  },
  menuContainer: {
    display: 'flex',
    justifyContent: 'flex-end',
    alignItems: 'center',
    marginBottom: '16px',
    position: 'sticky',
    top: '0',
    background: 'black',
    zIndex: '100',
    padding: '8px', // Add padding to the menu container
  },
  menuIcon: {
    marginRight: '16px',
    cursor: 'pointer',
    color: 'white',
    padding: '8px',
  },
  chatHistory: {
    minHeight: '10em',
    maxHeight: '20em',
    overflowY: 'auto',
    marginBottom: '16px',
    padding: '8px',
    background: 'gray',
    borderRadius: '4px',
    width: '100%',
    minWidth: 'calc(100% - 48px)',
    maxWidth: 'calc(100% - 48px)',
  },
  chatMessage: {
    marginBottom: '8px',
  },
  textField: {
    background: 'lightgray',
    width: '100%',
  },
  input: {
    '&::placeholder': {
      fontStyle: 'italic',
    },
  },
  icon: {
    cursor: 'pointer',
    transition: 'transform 0.3s',
  },
  rotatedIcon: {
    transform: 'rotate(-90deg)',
  },
  dropdownContainer: {
    position: 'relative',
    marginTop: '8px',
  },
  dropdown: {
    position: 'absolute',
    top: '100%',
    left: 0,
    background: 'lightgray',
    borderRadius: '4px',
    padding: '4px',
    boxShadow: '0 2px 5px rgba(0, 0, 0, 0.15)',
    zIndex: 1,
    minWidth: 'fit-content',
    maxWidth: 'fit-content',
  },
  dropdownItem: {
    cursor: 'pointer',
    padding: '4px 8px',
    '&:hover': {
      background: '#e0e0e0',
    },
    color: 'black',
  },
  uploadButton: {
    alignSelf: 'flex-end',
    marginBottom: '16px',
    marginRight: '8px',
    padding: '8px 16px',
  },
});

function App() {
  const classes = useStyles();
  const [hasText, setHasText] = useState(false);
  const [dropdownItems, setDropdownItems] = useState([]);
  const [chatMessages, setChatMessages] = useState([]);

  const handleTextChange = (event) => {
    const { value } = event.target;
    setHasText(value.length > 0);

    // Update dropdown items with paragraphs based on user input
    const lines = value.split('\n');
    setDropdownItems(lines);
  };

  const handleSend = () => {
    // Add the current text as a chat message
    const newChatMessage = document.getElementById('input-text').value;
    if (newChatMessage.trim() !== '') {
      setChatMessages([...chatMessages, newChatMessage]);
      document.getElementById('input-text').value = '';
    }
  };

  const handleUploadCV = () => {
    // Handle the CV upload functionality here
    console.log('CV uploaded');
  };

  return (
    <div className="App" style={{ background: 'darkgray' }}>
      <div className={classes.menuContainer}>
        <NotificationsIcon className={classes.menuIcon} />
        <EmailIcon className={classes.menuIcon} />
        <AccountCircleIcon className={classes.menuIcon} />
      </div>
      <div className={classes.container}>
        <header className="App-header">
        <Button
          variant="contained"
          color="primary"
          className={classes.uploadButton}
          onClick={handleUploadCV}
        >
          Upload CV
        </Button>
          <div className={classes.chatHistory}>
            {chatMessages.map((message, index) => (
              <div key={index} className={classes.chatMessage}>
                {message}
              </div>
            ))}
          </div>



          <div>
            <TextField
              id="input-text"
              label="Enter text"
              variant="filled"
              className={classes.textField}
              InputProps={{
                classes: {
                  input: classes.input,
                },
                endAdornment: (
                  <InputAdornment position="end">
                    <SendIcon
                      className={`${classes.icon} ${hasText ? classes.rotatedIcon : ''}`}
                      onClick={handleSend}
                    />
                  </InputAdornment>
                ),
              }}
              onChange={handleTextChange}
              inputProps={{
                style: { lineHeight: '1' },
                maxLength: 100,
              }}
            />
            {hasText && (
              <div className={classes.dropdownContainer}>
                <div className={classes.dropdown}>
                  {dropdownItems.map((item, index) => (
                    <div key={index} className={classes.dropdownItem}>
                      {item}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </header>
      </div>
    </div>
  );
}

export default App;
