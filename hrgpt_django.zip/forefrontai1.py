from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

import email
import imaplib
import time
from datetime import datetime

# Function to retrieve the email subject
def recmail(since_date):
    global x, notif1
    EMAIL = 'johnfuturs@gmail.com'
    PASSWORD = 'lzpxrvkdnuixywov'
    SERVER = 'imap.gmail.com'

    mail = imaplib.IMAP4_SSL(SERVER)
    mail.login(EMAIL, PASSWORD)
    mail.select('INBOX')

    since_date_str = since_date.strftime('%d-%b-%Y')

    status, data = mail.search(None, f'(UNSEEN FROM "notifications@forefront.ai" SINCE "{since_date_str}")')
    mail_ids = []

    for block in data:
        mail_ids += block.split()

    if not mail_ids:
        return

    latest_mail_id = mail_ids[-1]

    status, data = mail.fetch(latest_mail_id, '(RFC822)')
    for response_part in data:
        if isinstance(response_part, tuple):
            message = email.message_from_bytes(response_part[1])
            mail_subject = message['subject']
            mail.store(latest_mail_id, '+FLAGS', '\\Seen')
            x = mail_subject[:6]

            return x

# Initialize the Chrome driver in headless mode
options = webdriver.ChromeOptions()
options.add_argument('--headless')
driver = webdriver.Chrome('chromedriver', options=options)

# Open the webpage
driver.get('https://chat.forefront.ai/')

wait = WebDriverWait(driver, 50)  # Adjust the timeout as needed
time.sleep(10)

# Perform actions with the login button
login_button = wait.until(EC.visibility_of_element_located((By.XPATH, "//button[text()='Login']")))
login_button.click()
time.sleep(3)

# Enter the username and continue
username = driver.find_element(By.NAME, "identifier")
username.send_keys('johnfuturs@gmail.com')

cont_button = wait.until(EC.visibility_of_element_located((By.XPATH, "//button[text()='Continue']")))
cont_button.click()
time.sleep(3)

# Retrieve the email verification code
current_date = datetime.now()
since_date = current_date
x = ''
for _ in range(30):
    x = recmail(since_date)
    if x and len(x) >= 6:
        print(x)
        break
    since_date = datetime.now()
    time.sleep(1)

# Enter the verification code and continue
verif = driver.find_element(By.NAME, "codeInput-0")
verif.send_keys(x)

cont_free = wait.until(EC.visibility_of_element_located((By.XPATH, "//button[text()='Continue on Free']")))
cont_free.click()
time.sleep(3)

# Enter the chat message and click the send button
wait = WebDriverWait(driver, 50)
input_element = driver.find_element_by_css_selector('div[data-slate-editor="true"]')
input_element.send_keys("What is the capital of France?")
time.sleep(3)
button_element = driver.find_element_by_css_selector('div.cursor-pointer.self-end')
button_element.click()

# Wait for the response to appear
wait = WebDriverWait(driver, 10)
div_element = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, 'div.whitespace-pre-wrap.text-th-primary-dark.break-words')))

# Retrieve the text from the element and print it
text = div_element.text
print(text)

# Close the driver
driver.quit()
