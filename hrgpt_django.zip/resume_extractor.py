import fitz
import re
#import pyperclip
import pyautogui
import clipboard

from PyPDF2 import PdfReader
  
# creating a pdf reader object
reader = PdfReader('blas_resume (1)-converted.pdf')
  
# printing number of pages in pdf file
v = (len(reader.pages))
  
# getting a specific page from the pdf file
page = reader.pages[0]
text = ''
x=0
for x in range(v):
# extracting text from page
    page = reader.pages[x]
    text =  text + page.extract_text()
    x += 1
print(text)

cleaned_text = cleaned_text = re.sub(r"[^\w\s@.]", "", text.replace('\n', ''))
x = cleaned_text[:200]
clipboard.copy(x)
xx = clipboard.paste()
print(xx)
#pdf_path = "blas_resume (1)-converted.pdf"
#pdf = fitz.open(pdf_path)


