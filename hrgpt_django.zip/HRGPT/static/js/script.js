
var chatHistory = document.getElementById('chat-history');
document.getElementById('cv-file').addEventListener('change', function(event) {
  var fileInput = event.target;
  if (fileInput.files.length > 0) {
    var cvUploadedMessage = document.createElement('p');
    cvUploadedMessage.textContent = 'CV Uploaded and checking your info...';
    chatHistory.appendChild(cvUploadedMessage);

    // Disable the "Upload CV" button to prevent multiple file selections
    document.getElementById('upload-cv-button').disabled = true;

    // Submit the form asynchronously
    var formData = new FormData();
    formData.append('cv', fileInput.files[0]);
    fetch('upload_cv', {
      method: 'POST',
      headers: {
        'X-CSRFToken': getCSRFToken()
      },
      body: formData
    })
    .then(response => response.text())
    .then(data => {
      // Handle the response from the server
      console.log(data);
      // Parse the response JSON to extract the cv_text
       var responseObj = JSON.parse(data);
       var cvText = responseObj.cv_text;

       // Convert carriage returns to <p> elements
       var cvParagraphs = cvText.split('\n').map(function(cvLine) {
         var cvParagraph = document.createElement('p');
         cvParagraph.textContent = cvLine;
         return cvParagraph;
       });

       // Append the <p> elements to the chat history
       cvParagraphs.forEach(function(cvParagraph) {
         chatHistory.appendChild(cvParagraph);
       });
       // Create the "Is this you?" message
        var isThisYouMessage = document.createElement('p');
        isThisYouMessage.textContent = 'Is this you?';
        // Create the "Yes" button
        var yesButton = document.createElement('button');
        yesButton.textContent = 'Yes';
        yesButton.style.backgroundColor = 'yellow';

        // Create the "No" button
        var noButton = document.createElement('button');
        noButton.textContent = 'No';
        noButton.style.backgroundColor = 'violet';

        // Append the "Is this you?" message and buttons to the chat history
        chatHistory.appendChild(isThisYouMessage);
        chatHistory.appendChild(yesButton);
        chatHistory.appendChild(noButton);
         // Append the "Is this you?" message to the chat history
        //chatHistory.appendChild(isThisYouMessage);
    })
    .catch(error => {
      // Handle any errors
      console.error(error);
    });
  }
  function getCSRFToken() {
  const cookieValue = document.cookie
    .split('; ')
    .find(row => row.startsWith('csrftoken='))
    .split('=')[1];
  return cookieValue;
}
});

document.getElementById('upload-cv-button').addEventListener('click', function(event) {
  event.preventDefault();
  document.getElementById('cv-file').click();
});

// Function to update the chat history
//function updateChatHistory() {
//  fetch('get_chat_history')
//    .then(response => response.json())
//    .then(data => {
      // Clear the existing chat history
//      chatHistory.innerHTML = '';

      // Iterate through the chat history data
//      data.forEach(entry => {
//        var message = document.createElement('p');
//        message.textContent = entry.text;
//        message.classList.add(entry.sender);
//        chatHistory.appendChild(message);
//      });
//    })
//    .catch(error => {
//      console.error(error);
//    });
//}

// Poll for chat history updates every 5 seconds
//setInterval(updateChatHistory, 1000);

document.addEventListener('DOMContentLoaded', function() {
  var chatTextArea = document.getElementById('chat');
  var chatHistory = document.getElementById('chat-history');
  var postButton = document.querySelector('button[type="submit"]');

  postButton.addEventListener('click', function(event) {
    event.preventDefault();
    var text = chatTextArea.value.trim();
    if (text !== '') {
      var chatMessage = document.createElement('p');
      var chatText = document.createElement('span'); // Create a span element for the message text
      chatText.textContent = text;
      chatText.classList.add('user-text'); // Add the 'user-text' class to the message text
      chatMessage.appendChild(chatText); // Append the text span to the message element
      chatMessage.classList.add('user'); // Add the 'user' class to the user message
      chatHistory.appendChild(chatMessage);
      chatTextArea.value = '';

      // Check if the message contains the word "python"
      if (containsPython(text)) {
        // Create the Python blog button
        var button = document.createElement('button');
        button.textContent = 'Python Blog';
        button.addEventListener('click', openPythonBlog);

        // Append the Python blog button to the chat history
        chatHistory.appendChild(button);
      }
    }

    // Make a POST request to the server
    fetch('', { // Send the request to the current URL
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'X-CSRFToken': getCSRFToken() // Get the CSRF token from the cookie
      },
      body: 'chat=' + encodeURIComponent(text) // Include the chat message in the request body
    })
      .then(response => response.text())
      .then(data => {
        var responseMessage = document.createElement('p');
        var responseText = document.createElement('span'); // Create a span element for the response text
        responseText.textContent = data;
        responseText.classList.add('bot-text'); // Add the 'bot-text' class to the response text
        responseMessage.appendChild(responseText); // Append the text span to the message element
        responseMessage.classList.add('bot'); // Add the 'bot' class to the bot response
        chatHistory.appendChild(responseMessage);
      });

    // Function to get the CSRF token from the cookie
    function getCSRFToken() {
      const cookieValue = document.cookie
        .split('; ')
        .find(row => row.startsWith('csrftoken='))
        .split('=')[1];
      return cookieValue;
    }
  });

  // Function to check if the message contains the word "python"
  function containsPython(text) {
    return text.toLowerCase().includes('python');
  }

  // Function to open the Python blog link in a new tab or window
  function openPythonBlog(event) {
    event.preventDefault();
    window.open('https://pythonbitsnpieces.blogspot.com', '_blank');
  }
});

document.addEventListener('DOMContentLoaded', function() {
  var blogList = document.getElementById('blog-list');
  var jobCount = document.getElementById('job-count');

  fetch('https://jobslistapi.johnfuturs.repl.co/jobs')
    .then(response => response.json())
    .then(data => {
      const jobData = Object.values(data);

      blogList.innerHTML = '';

      jobData.forEach(job => {
        const jobObject = JSON.parse(job);
        const jobItem = document.createElement('li');
        const jobDetails = document.createElement('div');
        const jobIdElement = document.createElement('span');
        const positionElement = document.createElement('span');
        const descriptionElement = document.createElement('span');

        jobIdElement.textContent = `Job ID:     ${jobObject.id}`;
        positionElement.textContent = `Position:   ${jobObject.position}`;
        descriptionElement.textContent = `Description:${jobObject.description}`;

        jobDetails.appendChild(jobIdElement);
        jobDetails.appendChild(positionElement);
        jobItem.appendChild(jobDetails);
        jobItem.appendChild(descriptionElement);

        jobItem.classList.add('job-item');

        const lineBreak = document.createElement('hr');
        jobItem.appendChild(lineBreak);

        blogList.appendChild(jobItem);
      });

      const jobCount = jobData.length;
      const heading = document.querySelector('#blog-widget h2');
      heading.textContent = `${jobCount} Jobs Found`;
    })
    .catch(error => {
      console.error('Error:', error);
    });
});

$(window).on("load",document.getElementById("layoutBody").classList.add("dark-mode"));
