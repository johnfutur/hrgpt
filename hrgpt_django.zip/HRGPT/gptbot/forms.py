from django import forms

class HRGPT_Form(forms.Form):
    chat = forms.CharField(widget=forms.Textarea(attrs={'rows': 1, 'cols': 60}))
