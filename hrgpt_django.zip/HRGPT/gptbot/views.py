from django.shortcuts import render
from django.http import HttpResponse
from django.http import JsonResponse
import openai
# Create your views here.
from .forms import HRGPT_Form
from .models import Applicant
import requests
import json
import os
from django.conf import settings

import time
import email
import imaplib
from PyPDF2 import PdfReader
import re
import sys
from datetime import datetime
#import clipboard

from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities

def upload_cv(request):
    if request.method == 'POST':
        cv_file = request.FILES.get('cv')
        if cv_file:
            # Construct the file path for saving the CV
            file_path = os.path.join(settings.MEDIA_ROOT, 'docs', cv_file.name)

            # Save the CV file
            with open(file_path, 'wb') as file:
                for chunk in cv_file.chunks():
                    file.write(chunk)

            # Update the chat history
            chat_history = get_chat_history(request)  # Get the existing chat history
            chat_history.append('CV Uploaded and checking your info...')  # Append the CV uploaded message to the history

            time.sleep(1)
            sys.stderr = open(os.devnull, 'w')
            cv_text = forefrontai(file_path) # read cv and extract name, address and phone number

            chat_history.append(cv_text)  # Append the CV uploaded message to the history
            request.session['chat_history'] = chat_history
            # Construct the JSON response
            response_data = {
                'chat_history': chat_history,
                'cv_text': cv_text,
            }
            # Return a response with the updated chat history
            #return render(request, 'gptbot/base.html', {'chat_history': chat_history})
            return JsonResponse(response_data)
        else:
            # Return an error message if the 'cv' key is missing
            return HttpResponse('No CV file provided')

    # Render the initial page with the chat history
    chat_history = get_chat_history(request)
    return render(request, 'gptbot/base.html', {'chat_history': chat_history})
def get_chat_history(request):
    # Logic to retrieve the existing chat history
    # You can modify this function according to your chat history implementation
    # This is just a placeholder example
    if 'chat_history' in request.session:

        return request.session['chat_history']
    else:
        return []

def update_chat_history(request, message):
    if request.method == 'POST':
        data = request.POST.get('data')
        # Prepare the response data
        response_data = {
            'message': 'Data received and processed successfully',
            'result': 'Some result',
        }

        # Return a JSON response
        return JsonResponse(response_data)


def post_to_openai(request):
    if request.method == 'POST':
        # Set up OpenAI API credentials
        openai.api_key = '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'
        chat_text = request.POST.get('chat', '')
        response = openai.Completion.create(
            engine='text-davinci-003',
            prompt=chat_text,
            max_tokens=4048,
            n=1,
            stop=None,
            temperature=0.7
        )

        # Extract the generated response
        if response.choices:
            generated_text = response.choices[0].text.strip()
        else:
            generated_text = ''
        return HttpResponse(generated_text)

    return render(request, 'gptbot/base.html')

def extract_text(path):

    reader = PdfReader(path)
    text_cv = ''

    v = (len(reader.pages))
    for x_page in range(v):
        page = reader.pages[x_page]
        text = page.extract_text()
        cleaned_text = re.sub(r"[^\w\s@.+]", "", text.replace('\n', ''))
        text_cv = text_cv  + ' ' + cleaned_text
        print(len(text_cv))
    return text_cv[:5000]

# Initialize the Chrome driver

def recmail(since_date):
    global x, notif1
    EMAIL = 'johnfuturs@gmail.com'
    PASSWORD = 'lzpxrvkdnuixywov'
    SERVER = 'imap.gmail.com'

    mail = imaplib.IMAP4_SSL(SERVER)
    mail.login(EMAIL, PASSWORD)
    mail.select('INBOX')

    since_date_str = since_date.strftime('%d-%b-%Y')

    status, data = mail.search(None, f'(UNSEEN FROM "notifications@forefront.ai" SINCE "{since_date_str}")')
    mail_ids = []

    for block in data:
        mail_ids += block.split()
    if not mail_ids:
        #print('No new emails from notifications@forefront.ai')
        return
    latest_mail_id = mail_ids[-1]

    status, data = mail.fetch(latest_mail_id, '(RFC822)')
    for response_part in data:
        if isinstance(response_part, tuple):
            message = email.message_from_bytes(response_part[1])
            #mail_from = message['from']
            mail_subject = message['subject']
            mail.store(latest_mail_id, '+FLAGS', '\\Seen')
            x = mail_subject[:6]
            return x
def forefrontai(path):
    try:
        driver.quit()
    except:
        pass
# Initialize the Chrome driver in headless mode
    cv_text = extract_text(path)
    x_out=''
    options = Options()
    options.add_argument("--headless=new")
    options.add_argument("--start-maximized")
    options.add_argument('--remote-debugging-port=51625')
    options.add_argument('--no-sandbox')
    options.add_argument('--ignore-certificate-errors')

    webdriver_service = Service('chromedriver.exe')
    options.add_argument('--window-size=900,600')
    options.add_argument("--enable-logging")
    options.add_argument("--v=1")
    options.add_argument("--disable-extensions")
    options.add_argument("--proxy-server='direct://'")
    options.add_argument("--proxy-bypass-list=*")

    driver = webdriver.Chrome(service=webdriver_service, options=options)

    # Open the webpage
    driver.get('https://chat.forefront.ai/')

    wait = WebDriverWait(driver, 50)  # Adjust the timeout as needed
    time.sleep(10)

    login_button = wait.until(EC.visibility_of_element_located((By.XPATH, "//button[text()='Login']")))

    # Perform actions with the login button, e.g., click it
    login_button.click()
    time.sleep(3)
    wait = WebDriverWait(driver, 10)  # Adjust the timeout as needed

    username_locator = (By.NAME, "identifier")
    username = wait.until(EC.presence_of_element_located(username_locator))
    username.send_keys('johnfuturs@gmail.com')

    #password = driver.find_element_by_id('password')
    cont_button = wait.until(EC.visibility_of_element_located((By.XPATH, "//button[text()='Continue']")))

    # Perform actions with the login button, e.g., click it
    cont_button.click()
    time.sleep(3)

    current_date = datetime.now()
    since_date = current_date  # Modify this line to set your desired initial date and time
    x = ''
    for _ in range(30):
        x = recmail(since_date)
        if x and len(x) >= 6:
            #print(x)
            break
            since_date = datetime.now()  # Update the since_date to the current date and time
            time.sleep(1)

    verif = driver.find_element(By.NAME, "codeInput-0")
    verif.send_keys(x)
    wait = WebDriverWait(driver, 50)  # Adjust the timeout as needed

    cont_free = wait.until(EC.visibility_of_element_located((By.XPATH, "//button[text()='Continue on Free']")))

    # Perform actions with the login button, e.g., click it
    cont_free.click()
    time.sleep(10)



    ntext= 'Given the following CV text, extract Name, Address Phone Number following format <filed>:<value>' + ':' + cv_text[:5000]

    #clipboard.copy(ntext)

    wait = WebDriverWait(driver, 10)
    div_element = wait.until(EC.visibility_of_element_located((By.XPATH, "//div[@class='flex flex-col gap-2 max-w-[616px] min-w-[288px] w-full']")))
    #div_element = driver.find_element_by_xpath('//div[@class="flex flex-col gap-2 max-w-[616px] min-w-[288px] w-full"]')
    #force to execute javascript
    ActionChains(driver).click(div_element).perform()
    ActionChains(driver).send_keys(ntext).perform()
    time.sleep(5)
    textbox_element = WebDriverWait(driver, 10).until(EC.visibility_of_element_located((By.CSS_SELECTOR, 'div[data-slate-editor="true"]')))
    time.sleep(1)
    # Clear any existing text in the textbox
    textbox_element.clear()
    time.sleep(1)
    # Enter the desired text
    textbox_element.send_keys(Keys.CONTROL, 'v')
    time.sleep(1)
    textbox_element.send_keys(Keys.RETURN)

    time.sleep(5)

    if driver.execute_script("return document.readyState") == "complete":
        #    driver.get_screenshot_as_file("screenshot.png")
        wait = WebDriverWait(driver, 15)  # Maximum wait time of 10 seconds
        for _ in range(5):
            try:
                div_element = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, 'div.whitespace-pre-wrap.text-th-primary-dark.break-words')))
                time.sleep(5)
                x_out = div_element.text

                break
            except Exception as e:
                continue

    # Close the driver
    print(x_out)
    driver.quit()
    return x_out
