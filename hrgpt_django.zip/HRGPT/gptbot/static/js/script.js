document.getElementById('cv-file').addEventListener('change', function(event) {
  var fileInput = event.target;
  if (fileInput.files.length > 0) {
    var cvUploadedMessage = document.createElement('p');
    cvUploadedMessage.textContent = 'CV Uploaded';
    chatHistory.appendChild(cvUploadedMessage);

    // Fetch the CSRF token from the cookie
    function getCSRFToken() {
      const cookieValue = document.cookie
        .split('; ')
        .find(row => row.startsWith('csrftoken='))
        .split('=')[1];
      return cookieValue;
    }

    // Create a new FormData object
    var formData = new FormData();

    // Append the selected file to the FormData object
    formData.append('cv', fileInput.files[0]);

    // Make a POST request to the server with the FormData
    fetch('', {
      method: 'POST',
      headers: {
        'X-CSRFToken': getCSRFToken()
      },
      body: formData
    })
      .then(response => response.text())
      .then(data => {
        // Handle the server response as needed
        console.log('Server Response:', data);
      })
      .catch(error => {
        // Handle any errors that occurred during the POST request
        console.error('Error:', error);
      });
  }
});

document.addEventListener('DOMContentLoaded', function() {
  var chatTextArea = document.getElementById('chat');
  var chatHistory = document.getElementById('chat-history');
  var postButton = document.querySelector('button[type="submit"]');

  postButton.addEventListener('click', function(event) {
    event.preventDefault();
    var text = chatTextArea.value.trim();
    if (text !== '') {
      var chatMessage = document.createElement('p');
      chatMessage.textContent = text;
      chatHistory.appendChild(chatMessage);
      chatTextArea.value = '';

      // Check if the message contains the word "python"
      if (containsPython(text)) {
        // Create the Python blog button
        var button = document.createElement('button');
        button.textContent = 'Python Blog';
        button.addEventListener('click', openPythonBlog);

        // Append the Python blog button to the chat history
        chatHistory.appendChild(button);
      }
    }

    // Make a POST request to the server
    fetch('', { // Send the request to the current URL
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'X-CSRFToken': getCSRFToken() // Get the CSRF token from the cookie
      },
      body: 'chat=' + encodeURIComponent(text) // Include the chat message in the request body
    })
      .then(response => response.text())
      .then(data => {
        var responseMessage = document.createElement('p');
        responseMessage.textContent = data;
        chatHistory.appendChild(responseMessage);
      });

    // Function to get the CSRF token from the cookie
    function getCSRFToken() {
      const cookieValue = document.cookie
        .split('; ')
        .find(row => row.startsWith('csrftoken='))
        .split('=')[1];
      return cookieValue;
    }
  });

  // Function to check if the message contains the word "python"
  function containsPython(text) {
    return text.toLowerCase().includes('python');
  }

  // Function to open the Python blog link in a new tab or window
  function openPythonBlog(event) {
    event.preventDefault();
    window.open('https://pythonbitsnpieces.blogspot.com', '_blank');
  }
});
