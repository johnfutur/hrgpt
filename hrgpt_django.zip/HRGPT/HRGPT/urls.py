"""
URL configuration for HRGPT project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
#from gptbot.views import post_to_openai
from gptbot import views
urlpatterns = [

    path("admin/", admin.site.urls),
    path('', views.post_to_openai, name='home'),
    path('post_to_openai', views.post_to_openai, name='post_to_openai'),
    path('upload_cv', views.upload_cv, name='upload_cv'),
    path('update_chat_history', views.update_chat_history, name='update_chat_history'),
    path('get_chat_history', views.get_chat_history, name='get_chat_history'), 
]
