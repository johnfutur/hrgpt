import email
import imaplib
import time
from datetime import datetime

def recmail(since_date):
    global x, notif1
    EMAIL = 'johnfuturs@gmail.com'
    PASSWORD = 'lzpxrvkdnuixywov'
    SERVER = 'imap.gmail.com'

    mail = imaplib.IMAP4_SSL(SERVER)
    mail.login(EMAIL, PASSWORD)
    mail.select('INBOX')

    since_date_str = since_date.strftime('%d-%b-%Y')

    status, data = mail.search(None, f'(UNSEEN FROM "notifications@forefront.ai" SINCE "{since_date_str}")')
    mail_ids = []

    for block in data:
        mail_ids += block.split()

    if not mail_ids:
        #print('No new emails from notifications@forefront.ai')
        return

    latest_mail_id = mail_ids[-1]

    status, data = mail.fetch(latest_mail_id, '(RFC822)')
    for response_part in data:
        if isinstance(response_part, tuple):
            message = email.message_from_bytes(response_part[1])
            #mail_from = message['from']
            mail_subject = message['subject']
            mail.store(latest_mail_id, '+FLAGS', '\\Seen')
            x = mail_subject[:6]

            #print(x)
            
            return x
            
current_date = datetime.now()
since_date = current_date  # Modify this line to set your desired initial date and time

for _ in range(30):
    x = recmail(since_date)
    if x and len(x) >= 6:
        print(x)
        break
    since_date = datetime.now()  # Update the since_date to the current date and time
    time.sleep(1)
