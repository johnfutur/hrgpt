import requests
import json

def get_chat_completion(message):
    url = "https://api.openai.com/v1/chat/completions"
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer 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"
    }
    data = {
        "model": "gpt-4",
        "messages": [{"role": "user", "content": message}],
        "temperature": 0.7
    }

    response = requests.post(url, headers=headers, data=json.dumps(data))
    response_json = response.json()
    
    if 'choices' in response_json:
        choices = response_json['choices']
        if len(choices) > 0:
            return choices[0]['message']['content']
    
    return None

# Example usage
user_message = "Say this is a test!"
completion = get_chat_completion(user_message)

if completion:
    print("AI's response:", completion)
else:
    print("No response from the AI.")

def get_model_details():
    url = "https://api.openai.com/v1/models/text-davinci-003"
    headers = {
        "Authorization": "Bearer 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"
    }

    response = requests.get(url, headers=headers)
    response_json = response.json()

    return response_json

# Example usage
model_details = get_model_details()
print("Model details:", model_details)    
