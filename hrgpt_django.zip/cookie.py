import browsercookie

# Save Chrome cookies
chrome_cookies = browsercookie.chrome()

# Write cookies to a file
with open('cookies.txt', 'w') as f:
    for cookie in chrome_cookies:
        f.write(f"{cookie.name}\t{cookie.value}\t{cookie.domain}\n")

# Add cookies from the file
with open('cookies.txt', 'r') as f:
    for line in f:
        name, value, domain = line.strip().split('\t')
        cookie = browsercookie.Cookie(name=name, value=value, domain=domain)
        chrome_cookies.set_cookie(cookie)
