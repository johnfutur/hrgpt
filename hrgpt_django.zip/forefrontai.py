from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from bs4 import BeautifulSoup

import email
import imaplib
import time

from datetime import datetime
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
#from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
import clipboard

from PyPDF2 import PdfReader
import re
import os
import sys

# Redirect warnings to os.devnull
sys.stderr = open(os.devnull, 'w')


def extract_text():
    pdf_path = "blas_resume (1)-converted.pdf"
    reader = PdfReader(pdf_path)
    page = reader.pages[0]
    text = page.extract_text()
    cleaned_text = cleaned_text = re.sub(r"[^\w\s@.]", "", text.replace('\n', ''))
    x = cleaned_text[:650]
    
    return cleaned_text[:650]

# Initialize the Chrome driver

def recmail(since_date):
    global x, notif1
    EMAIL = 'johnfuturs@gmail.com'
    PASSWORD = 'lzpxrvkdnuixywov'
    SERVER = 'imap.gmail.com'

    mail = imaplib.IMAP4_SSL(SERVER)
    mail.login(EMAIL, PASSWORD)
    mail.select('INBOX')

    since_date_str = since_date.strftime('%d-%b-%Y')

    status, data = mail.search(None, f'(UNSEEN FROM "notifications@forefront.ai" SINCE "{since_date_str}")')
    mail_ids = []

    for block in data:
        mail_ids += block.split()
    if not mail_ids:
        #print('No new emails from notifications@forefront.ai')
        return
    latest_mail_id = mail_ids[-1]

    status, data = mail.fetch(latest_mail_id, '(RFC822)')
    for response_part in data:
        if isinstance(response_part, tuple):
            message = email.message_from_bytes(response_part[1])
            #mail_from = message['from']
            mail_subject = message['subject']
            mail.store(latest_mail_id, '+FLAGS', '\\Seen')
            x = mail_subject[:6]
            return x
        
cv_text = extract_text()
# Initialize the Chrome driver in headless mode       
options = Options()
options.add_argument("--headless=new")
options.add_argument("--start-maximized")
options.add_argument('--remote-debugging-port=51625')
options.add_argument('--no-sandbox')
options.add_argument('--ignore-certificate-errors')

webdriver_service = Service('chromedriver.exe')
options.add_argument('--window-size=900,600')
options.add_argument("--enable-logging")
options.add_argument("--v=1")
options.add_argument("--disable-extensions")
options.add_argument("--proxy-server='direct://'")
options.add_argument("--proxy-bypass-list=*")

driver = webdriver.Chrome(service=webdriver_service, options=options)

# Open the webpage
driver.get('https://chat.forefront.ai/')

wait = WebDriverWait(driver, 50)  # Adjust the timeout as needed
time.sleep(10)

login_button = wait.until(EC.visibility_of_element_located((By.XPATH, "//button[text()='Login']")))

# Perform actions with the login button, e.g., click it
login_button.click()
time.sleep(3)
wait = WebDriverWait(driver, 10)  # Adjust the timeout as needed

username_locator = (By.NAME, "identifier")
username = wait.until(EC.presence_of_element_located(username_locator))
username.send_keys('johnfuturs@gmail.com')

#password = driver.find_element_by_id('password')
cont_button = wait.until(EC.visibility_of_element_located((By.XPATH, "//button[text()='Continue']")))

# Perform actions with the login button, e.g., click it
cont_button.click()
time.sleep(3)

current_date = datetime.now()
since_date = current_date  # Modify this line to set your desired initial date and time
x = ''
for _ in range(30):
    x = recmail(since_date)
    if x and len(x) >= 6:
        print(x)
        break
    since_date = datetime.now()  # Update the since_date to the current date and time
    time.sleep(1)

verif = driver.find_element(By.NAME, "codeInput-0")
verif.send_keys(x)
wait = WebDriverWait(driver, 50)  # Adjust the timeout as needed
#password = driver.find_element_by_id('password')
cont_free = wait.until(EC.visibility_of_element_located((By.XPATH, "//button[text()='Continue on Free']")))

# Perform actions with the login button, e.g., click it
cont_free.click()
time.sleep(10)



ntext= 'Given the following CV text, extract Name, Address Phone Number following format <filed>:<value>' + ':' + cv_text[:650]

clipboard.copy(ntext)

wait = WebDriverWait(driver, 10)
div_element = driver.find_element_by_xpath('//div[@class="flex flex-col gap-2 max-w-[616px] min-w-[288px] w-full"]')
#force to execute javascript
ActionChains(driver).click(div_element).perform()
ActionChains(driver).send_keys(ntext).perform()
time.sleep(5)
textbox_element = WebDriverWait(driver, 10).until(
    EC.visibility_of_element_located((By.CSS_SELECTOR, 'div[data-slate-editor="true"]'))
)
time.sleep(1)
# Clear any existing text in the textbox
textbox_element.clear()
time.sleep(1)
# Enter the desired text
textbox_element.send_keys(Keys.CONTROL, 'v')
time.sleep(1)
textbox_element.send_keys(Keys.RETURN)
#driver.get_screenshot_as_file("screenshot2.png")
#driver.get_screenshot_as_file("screenshot1.png")    
time.sleep(5)    

if driver.execute_script("return document.readyState") == "complete":
#    driver.get_screenshot_as_file("screenshot.png")
    wait = WebDriverWait(driver, 15)  # Maximum wait time of 10 seconds
    for _ in range(5):
        try:
            div_element = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, 'div.whitespace-pre-wrap.text-th-primary-dark.break-words')))
            time.sleep(5)
            text = div_element.text
            print(text)
            break
        except Exception as e:
            continue

# Close the driver
driver.quit()
